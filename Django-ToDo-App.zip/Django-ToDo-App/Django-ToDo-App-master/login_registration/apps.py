from django.apps import AppConfig


class Login_registrationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'login_registration'
